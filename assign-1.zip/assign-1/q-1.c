#include<stdio.h>
#include<unistd.h>
#include<string.h>

int main(){
	printf("Welcome\n");
	fork();//create child process
	printf("PID:%d,PPID:%d\n",getpid(),getppid());
	while(1);
	}
	
//OUTPUT
/*
Welcome
PID:8642,PPID:8569
PID:8643,PPID:8642
*/
