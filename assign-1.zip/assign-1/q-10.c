#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main()
{
	fork();
	fork();
	fork();
	printf("hello\n");
	while(1);
	return 0;
}

//top
//pstree -p <PID>
/*
q-10(7811)─┬─q-10(7812)─┬─q-10(7814)───q-10(7817)
           │            └─q-10(7816)
           ├─q-10(7813)───q-10(7818)
           └─q-10(7815)
*/
