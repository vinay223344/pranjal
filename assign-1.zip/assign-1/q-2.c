#include<stdio.h>
#include<unistd.h>

int main(){
	printf("Welcome\n");
	fork();
	fork();
	fork();
	printf("PID : %d ,PPID:%d\n",getpid(),getppid());
	while(1);
	}
	
/*
Welcome
PID : 8780 ,PPID:8569
PID : 8782 ,PPID:8780
PID : 8781 ,PPID:8780
PID : 8783 ,PPID:8781
PID : 8787 ,PPID:8783
PID : 8786 ,PPID:8781
PID : 8784 ,PPID:8780
PID : 8785 ,PPID:8782
*/
