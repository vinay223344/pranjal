#include<stdio.h>
#include<unistd.h>

int main(){
	printf("Welcome to Moschip\n");
	if(fork()){
		printf("parent...\n");
		}
	else
	{
		printf("Child..\n");
	}
	printf("both...\n");
	}

/*

Welcome to Moschip
parent...
both...
Child..
both...
*/

