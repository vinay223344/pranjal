#include<stdio.h>
#include<unistd.h>

int main(){
	int i;
	printf("Welcome to Moschip\n");
	for(i=0;i<3;i++){
		if(fork()==0){
			printf("i%d..pid%d...ppid%d\n",i,getpid(),getppid());
			}
			else
			;
			}
			while(1);
			}
/*
Welcome to Moschip
i0..pid9009...ppid9008
i1..pid9010...ppid9008
i2..pid9011...ppid9008
i2..pid9013...ppid9009
i2..pid9014...ppid9010
i1..pid9012...ppid9009
i2..pid9015...ppid9012
*/
