#include<stdio.h>
#include<unistd.h>

void main(void)
{
if(fork()==0){
	printf("in child before sleep pid =%d ppid =%d \n", getpid() ,getppid());
	sleep(10);
} else {
	printf("in parent pid =%d ppid =%d \n", getpid(), getppid());
	sleep(5);
}
}

/*
in parent pid =9187 ppid =8569 
in child before sleep pid =9188 ppid =9187 
*/

