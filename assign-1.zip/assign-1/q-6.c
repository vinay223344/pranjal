#include<stdio.h>
#include<unistd.h>
void main(void)
{
	if(fork()==0) {//child is executing for 10 seconds only
		printf("in child pid =%d ppid =%d \n", getpid(), getppid());
		sleep(10);
		printf("Child is terminating \n");
	}
	else {//parent is executing infinitely
		printf("in parent pid =%d ppid =%d \n", getpid(), getppid());
		while(1);
	}
}

/*
in parent pid =16339 ppid =16313 
in child pid =16340 ppid =16339 
Child is terminating 

*/
