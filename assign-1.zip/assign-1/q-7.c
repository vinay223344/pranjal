#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int main()
{
	int i=5;
	int ret=fork();
	if(ret==-1)
	{
		perror("fork");
		exit(0);
	}
	if(ret>0)
	{
		i+=10;
		printf("i=%d     %p\n",i,&i);
	}
	else
	{
		i=i+30;
		printf("i=%d 	 %p\n",i,&i);
	}
}

/*
i=15     0x7fff31818f30
i=35 	 0x7fff31818f30
*/
