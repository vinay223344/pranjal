#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
	{
	int ret=fork();
	if(ret==-1)
		{
		perror("fork");
		exit(0);
	}
	if(ret>0)            
	{//exclusively in parent process
			int ret1=fork();
		if(ret1==-1)
		{
			perror("child2");
			exit(0);
		}
		if(ret1==0)
		{
			printf("child2 PID=%d PPID=%d\n",getpid(),getppid());
		}
		else
		{//exclusive parent code
			sleep(20);
			printf("Parent process PID=%d\n",getpid());
		}
	}
	else
	{//exclusively in child1 process
		sleep(10);
		printf("child1 PID=%d PPID= %d\n",getpid(),getppid());
	}
}

/*
child2 PID=17003 PPID=17001
child1 PID=17002 PPID= 17001
Parent process PID=17001
*/
